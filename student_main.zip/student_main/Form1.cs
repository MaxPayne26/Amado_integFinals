using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace student_main
{
    public partial class SQL : Form
    {
        private MySqlConnection connection = new MySqlConnection();
        private MySqlCommand cmd = new MySqlCommand();
        private MySqlDataAdapter adapter = new MySqlDataAdapter();
        private DataTable dataTable = new DataTable();


        private readonly string connectionString = "Server=localhost;Database=student_maint;User ID=root;Password=;";

        public SQL()
        {
            InitializeComponent();
            InitializeDatabase(connectionString);
            InitializeDataGridView();
            InitializeSearchControls();
        }
        private void InitializeSearchControls()
        {
            // Add items to cmbSearchBy
            cmbsearch.Items.AddRange(new string[] { "Student ID", "First Name", "Last Name", "Course" });

            // Set default selection
            cmbsearch.SelectedIndex = 0;

            // Set up AutoComplete for txtSearch based on the selected attribute
            txtsearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtsearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtsearch.AutoCompleteCustomSource = GetAutoCompleteSource();
        }

        private AutoCompleteStringCollection GetAutoCompleteSource()
        {
            // Retrieve distinct values for the selected attribute from the DataTable
            AutoCompleteStringCollection autoCompleteSource = new AutoCompleteStringCollection();

            switch (cmbsearch.SelectedItem.ToString())
            {
                case "Student ID":
                    foreach (DataRow row in dataTable.Rows)
                    {
                        autoCompleteSource.Add(row["student_id"].ToString());
                    }
                    break;
                case "First Name":
                    foreach (DataRow row in dataTable.Rows)
                    {
                        autoCompleteSource.Add(row["Fname"].ToString());
                    }
                    break;
                case "Last Name":
                    foreach (DataRow row in dataTable.Rows)
                    {
                        autoCompleteSource.Add(row["Lname"].ToString());
                    }
                    break;
                case "Course":
                    foreach (DataRow row in dataTable.Rows)
                    {
                        autoCompleteSource.Add(row["Course"].ToString());
                    }
                    break;
            }

            return autoCompleteSource;
        }
        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            txtsearch.AutoCompleteCustomSource = GetAutoCompleteSource();
        }

        private void InitializeDatabase(string connectionString)
        {
            connection = new MySqlConnection(connectionString);
            cmd = new MySqlCommand();
            cmd.Connection = connection;
        }

        private void InitializeDataGridView()
        {
            Datagrid1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Datagrid1.MultiSelect = false;
            Datagrid1.ReadOnly = true;
            Datagrid1.AllowUserToAddRows = false;
            Datagrid1.AllowUserToDeleteRows = false;
            Datagrid1.AllowUserToOrderColumns = true;
            Datagrid1.EditMode = DataGridViewEditMode.EditProgrammatically;


            adapter = new MySqlDataAdapter("SELECT * FROM student", connection);
            dataTable = new DataTable();
            adapter.Fill(dataTable);
            Datagrid1.DataSource = dataTable;
        }

        private void RefreshDataGrid()
        {
            dataTable.Clear();
            adapter.Fill(dataTable);
        }

        private void Datagrid1_SelectionChanged(object sender, EventArgs e)
        {
            if (Datagrid1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = Datagrid1.SelectedRows[0];

                txtstudent_id.Text = selectedRow.Cells["student_id"].Value.ToString();
                txtfname.Text = selectedRow.Cells["Fname"].Value.ToString();
                txtlname.Text = selectedRow.Cells["Lname"].Value.ToString();
                txtcourse.Text = selectedRow.Cells["Course"].Value.ToString();
            }
        }

        private bool AreTextFieldsFilled()
        {
            return !string.IsNullOrEmpty(txtstudent_id.Text) &&
                   !string.IsNullOrEmpty(txtfname.Text) &&
                   !string.IsNullOrEmpty(txtlname.Text) &&
                   !string.IsNullOrEmpty(txtcourse.Text);
        }

        private static bool IsValidStudentIdFormat(string studentId)
        {
            return studentId.Length == 8 && int.TryParse(studentId, out _);
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Open the database connection
                connection.Open();

                // Check if all text fields are filled
                if (!AreTextFieldsFilled())
                {
                    MessageBox.Show("All fields must be filled.");
                    return;
                }

                // Validate student_id format
                if (!IsValidStudentIdFormat(txtstudent_id.Text))
                {
                    MessageBox.Show("Invalid student_id format. It must contain 8 digits.");
                    return;
                }

                // Parse values from text fields
                int studentId = int.Parse(txtstudent_id.Text);
                string firstName = txtfname.Text;
                string lastName = txtlname.Text;
                string course = txtcourse.Text;

                // Set up the SQL command using parameterized query to prevent SQL injection
                cmd.CommandText = "INSERT INTO student (student_id, Fname, Lname, Course) " +
                                  "VALUES (@studentId, @firstName, @lastName, @course)";

                // Add parameters to the command
                cmd.Parameters.AddWithValue("@studentId", studentId);
                cmd.Parameters.AddWithValue("@firstName", firstName);
                cmd.Parameters.AddWithValue("@lastName", lastName);
                cmd.Parameters.AddWithValue("@course", course);

                // Execute the INSERT query
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record added successfully!");

                // Disable the student_id TextBox after adding a new record
                txtstudent_id.Enabled = false;
            }
            catch (Exception ex)
            {
                // Display an error message if an exception occurs
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                // Close the database connection and refresh the data grid
                connection.Close();
                RefreshDataGrid();
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();

                // Check if there is a selected row in the DataGridView
                if (Datagrid1.SelectedRows.Count > 0)
                {
                    int studentId = int.Parse(txtstudent_id.Text);

                    cmd.CommandText = $"DELETE FROM student WHERE student_id = @studentId";
                    cmd.Parameters.AddWithValue("@studentId", studentId);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record deleted successfully!");
                }
                else
                {
                    MessageBox.Show("Please select a student to delete.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
                RefreshDataGrid();
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();

                if (!AreTextFieldsFilled())
                {
                    MessageBox.Show("All fields must be filled.");
                    return;
                }

                if (!IsValidStudentIdFormat(txtstudent_id.Text))
                {
                    MessageBox.Show("Invalid student_id format. It must contain 8 digits.");
                    return;
                }

                int studentId = int.Parse(txtstudent_id.Text);
                string firstName = txtfname.Text;
                string lastName = txtlname.Text;
                string course = txtcourse.Text;

                cmd.CommandText = "UPDATE student SET Fname = @firstName, Lname = @lastName, Course = @course " +
                                  "WHERE student_id = @studentId";

                cmd.Parameters.AddWithValue("@studentId", studentId);
                cmd.Parameters.AddWithValue("@firstName", firstName);
                cmd.Parameters.AddWithValue("@lastName", lastName);
                cmd.Parameters.AddWithValue("@course", course);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Record updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
                RefreshDataGrid();
                txtstudent_id.Enabled = true;
            }
        }

        private void txtsearch_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                connection.Open();

                string columnName = "";
                switch (cmbsearch.SelectedItem.ToString())
                {
                    case "Student ID":
                        columnName = "student_id";
                        break;
                    case "First Name":
                        columnName = "Fname";
                        break;
                    case "Last Name":
                        columnName = "Lname";
                        break;
                    case "Course":
                        columnName = "Course";
                        break;
                }

                string searchTerm = txtsearch.Text;

                adapter.SelectCommand = new MySqlCommand($"SELECT * FROM student WHERE {columnName} LIKE @searchTerm", connection);
                adapter.SelectCommand.Parameters.AddWithValue("@searchTerm", $"%{searchTerm}%");

                dataTable.Clear();
                adapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
