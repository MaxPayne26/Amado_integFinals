<?php
require 'vendor/autoload.php'; // Include Composer's autoloader
require 'assets/database/database.php'; // Include your database connection

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $errorMessage = ''; // Initialize the variable

    // Get form data and sanitize
    $username = htmlspecialchars($_POST["name"]);
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    $message = htmlspecialchars($_POST["message"]);

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errorMessage = 'Invalid email format';
    } elseif (!preg_match("/^[a-zA-Z ]*$/", $username)) {
        $errorMessage = 'Name must contain only letters and spaces';
    } else {
        // Create a new PHPMailer instance
        $mail = new PHPMailer(true);

        try {
            // SMTP settings (consider using environment variables or a configuration file for sensitive data)
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  // Change this to your SMTP server
            $mail->SMTPAuth = true;
            $mail->Username = 'mr.red092697@gmail.com'; // Change this to your SMTP username
            $mail->Password = 'efulhcbbqpwyueou'; // Change this to your SMTP password
            $mail->SMTPSecure = 'tls';  // Change to 'ssl' if required
            $mail->Port = 587;  // Change this to your SMTP port

            // Sender information
            $mail->setFrom($email, $username);
            
            // Recipient email
            $mail->addAddress('mr.red092697@gmail.com');  // Change this to the recipient's email address
            
            // Email content
            $mail->isHTML(true);
            $mail->Subject = 'New Contact Form Submission';
            $mail->Body    = 'Username: ' . $username . '<br>Email: ' . $email . '<br>Message: ' . $message;

            // Send the email
            $mail->send();

            // Insert into the database using prepared statements
            $query = "INSERT INTO users (username, email, message) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('sss', $username, $email, $message);
            $stmt->execute();
            $stmt->close();

            // Return a success message
            echo 'sent and saved to the database';
        } catch (Exception $e) {
            $errorMessage = 'Error: ' . $e->getMessage();
            // Return an error message
            echo $errorMessage;
        }
    }
} else {
    // Return an error message if accessed directly
    echo 'Direct access not allowed';
}
?>
