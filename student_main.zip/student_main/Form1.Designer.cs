﻿namespace student_main
{
    partial class SQL
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            txtstudent_id = new TextBox();
            txtsearch = new TextBox();
            txtcourse = new TextBox();
            txtlname = new TextBox();
            txtfname = new TextBox();
            cmbsearch = new ComboBox();
            BtnAdd = new Button();
            BtnDelete = new Button();
            BtnUpdate = new Button();
            Datagrid1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)Datagrid1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(352, 9);
            label1.Name = "label1";
            label1.Size = new Size(256, 28);
            label1.TabIndex = 0;
            label1.Text = "STUDENT MAINTENANCE";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(478, 62);
            label3.Name = "label3";
            label3.Size = new Size(94, 25);
            label3.TabIndex = 2;
            label3.Text = "Seach By:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(46, 230);
            label4.Name = "label4";
            label4.Size = new Size(75, 25);
            label4.TabIndex = 3;
            label4.Text = "Course:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(17, 173);
            label5.Name = "label5";
            label5.Size = new Size(106, 25);
            label5.TabIndex = 4;
            label5.Text = "Last Name:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(15, 117);
            label6.Name = "label6";
            label6.Size = new Size(108, 25);
            label6.TabIndex = 5;
            label6.Text = "First Name:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(15, 59);
            label7.Name = "label7";
            label7.Size = new Size(108, 25);
            label7.TabIndex = 6;
            label7.Text = "Student ID:";
            // 
            // txtstudent_id
            // 
            txtstudent_id.Location = new Point(129, 53);
            txtstudent_id.Name = "txtstudent_id";
            txtstudent_id.Size = new Size(217, 31);
            txtstudent_id.TabIndex = 7;
            // 
            // txtsearch
            // 
            txtsearch.Location = new Point(746, 59);
            txtsearch.Name = "txtsearch";
            txtsearch.Size = new Size(217, 31);
            txtsearch.TabIndex = 8;
            txtsearch.TextChanged += txtsearch_TextChanged_1;
            // 
            // txtcourse
            // 
            txtcourse.Location = new Point(127, 224);
            txtcourse.Name = "txtcourse";
            txtcourse.Size = new Size(217, 31);
            txtcourse.TabIndex = 9;
            // 
            // txtlname
            // 
            txtlname.Location = new Point(129, 170);
            txtlname.Name = "txtlname";
            txtlname.Size = new Size(217, 31);
            txtlname.TabIndex = 10;
            // 
            // txtfname
            // 
            txtfname.Location = new Point(129, 111);
            txtfname.Name = "txtfname";
            txtfname.Size = new Size(217, 31);
            txtfname.TabIndex = 11;
            // 
            // cmbsearch
            // 
            cmbsearch.FormattingEnabled = true;
            cmbsearch.Location = new Point(578, 59);
            cmbsearch.Name = "cmbsearch";
            cmbsearch.Size = new Size(162, 33);
            cmbsearch.TabIndex = 12;
            cmbsearch.Text = "-Select Option-";
            // 
            // BtnAdd
            // 
            BtnAdd.Location = new Point(222, 287);
            BtnAdd.Name = "BtnAdd";
            BtnAdd.Size = new Size(124, 38);
            BtnAdd.TabIndex = 13;
            BtnAdd.Text = "ADD";
            BtnAdd.UseVisualStyleBackColor = true;
            BtnAdd.Click += BtnAdd_Click;
            // 
            // BtnDelete
            // 
            BtnDelete.Location = new Point(222, 341);
            BtnDelete.Name = "BtnDelete";
            BtnDelete.Size = new Size(124, 38);
            BtnDelete.TabIndex = 14;
            BtnDelete.Text = "DELETE";
            BtnDelete.UseVisualStyleBackColor = true;
            BtnDelete.Click += BtnDelete_Click;
            // 
            // BtnUpdate
            // 
            BtnUpdate.Location = new Point(220, 385);
            BtnUpdate.Name = "BtnUpdate";
            BtnUpdate.Size = new Size(124, 38);
            BtnUpdate.TabIndex = 15;
            BtnUpdate.Text = "UPDATE";
            BtnUpdate.UseVisualStyleBackColor = true;
            BtnUpdate.Click += BtnUpdate_Click;
            // 
            // Datagrid1
            // 
            Datagrid1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Datagrid1.Location = new Point(352, 96);
            Datagrid1.Name = "Datagrid1";
            Datagrid1.RowHeadersWidth = 62;
            Datagrid1.RowTemplate.Height = 33;
            Datagrid1.Size = new Size(670, 338);
            Datagrid1.TabIndex = 16;
            // 
            // SQL
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1034, 470);
            Controls.Add(Datagrid1);
            Controls.Add(BtnUpdate);
            Controls.Add(BtnDelete);
            Controls.Add(BtnAdd);
            Controls.Add(cmbsearch);
            Controls.Add(txtfname);
            Controls.Add(txtlname);
            Controls.Add(txtcourse);
            Controls.Add(txtsearch);
            Controls.Add(txtstudent_id);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Name = "SQL";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)Datagrid1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox txtstudent_id;
        private TextBox txtsearch;
        private TextBox txtcourse;
        private TextBox txtlname;
        private TextBox txtfname;
        private ComboBox cmbsearch;
        private Button BtnAdd;
        private Button BtnDelete;
        private Button BtnUpdate;
        private DataGridView Datagrid1;
    }
}